package com.example.musicjava;

public class AudioInputStream {
}
